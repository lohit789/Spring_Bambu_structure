﻿'use strict';

angular.module('app',
    [
        // Dependency Inject Goes inside this array
        'ui.router',  // we inject/load ui-router for routing
        'app.controllers', // we inject/load the controllers
    ]
)
    .config(['$stateProvider',
        function ($stateProvider) {
            // UI States, URL Routing & Mapping. 

            // our routers, self explanatory
            $stateProvider
                .state('home', {
                    url: '/',
                    templateUrl: './View/Home.html',
                    //controller: 'HomeController'
                })
                .state('movies', {
                    url: '/movies',
                    templateUrl: './View/Movies.html',
                    controller: 'MoviesController'
                })
				.state('peoples', {
                    url: '/peoples',
                    templateUrl: './View/people.html',
                    controller: 'PeopleController'
                })
				.state('planets', {
                    url: '/planets',
                    templateUrl: './View/planets.html',
                    controller: 'PlanetsController'
                })
				.state('species', {
                    url: '/species',
                    templateUrl: './View/species.html',
                    controller: 'SpeciesController'
                })
				.state('vehicles', {
                    url: '/vehicles',
                    templateUrl: './View/vehicles.html',
                    controller: 'VehiclesController'
                })
                .state('otherwise', {
                    url: '*path',
                    templateUrl: '/View/Error.html',
                    controller: 'ErrorCtrl'
                });
        }]

        );
