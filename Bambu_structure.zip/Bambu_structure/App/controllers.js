﻿angular.module('app.controllers', [])

    .controller('MoviesController', function ($scope, $http)
    {
        // this will do for now
        //$scope.movies =
        //[
        //    { Id: 1, Name: "Fight Club",Director: "David Fincher" },
        //    { Id: 2, Name: "Into The Wild", Director: "Sean Penn" },
        //    { Id: 3, Name: "Dancer in the Dark", Director:"Lars von Trier " }
        //];

        $http({
            method: 'GET',
            //url: 'http://localhost/angular-webapi/api/movies'
			url: 'https://swapi.co/api/films/'
        })
         .success(function (data)
         {             
             $scope.movies = data;
         });
        

    });
	.controller('PeopleController', function ($scope, $http)
    {      
        $http({
            method: 'GET',
            //url: 'http://localhost/angular-webapi/api/people'
			url: 'https://swapi.co/api/people/'
        })
         .success(function (data)
         {             
             $scope.people = data;
         });
        

    });
	.controller('PlanetsController', function ($scope, $http)
    {      
        $http({
            method: 'GET',
            //url: 'http://localhost/angular-webapi/api/planets'
			url: 'https://swapi.co/api/planets/'
        })
         .success(function (data)
         {             
             $scope.planets = data;
         });
        

    });
		.controller('SpeciesController', function ($scope, $http)
    {      
        $http({
            method: 'GET',
            //url: 'http://localhost/angular-webapi/api/species'
			url: 'https://swapi.co/api/species/'
        })
         .success(function (data)
         {             
             $scope.species = data;
         });
        

    });
		.controller('VehiclesController', function ($scope, $http)
    {      
        $http({
            method: 'GET',
            //url: 'http://localhost/angular-webapi/api/vehicles'
			url: 'https://swapi.co/api/vehicles/'
        })
         .success(function (data)
         {             
             $scope.vehicles = data;
         });
        

    });
	